<?php
// Copiez ce fichier en config.php (NE PAS versionner config.php)
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'saes3-mbourem',
        'user' => 'saes3-mbourem',
        'pass' => '52Un/Y70UHN/k43G',
        'charset' => 'utf8mb4',
    ],
    // Secret pour signer les tokens (mieux: variable d'env API_JWT_SECRET)
    'jwt_secret' => 'dev-secret-change-me',
    // CORS: mets plutôt ton domaine si tu veux restreindre.
    'cors' => [
        'allow_origin' => '*',
        'allow_headers' => 'Content-Type, Authorization',
        'allow_methods' => 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    ],
];
