package fr.iut.sae.app.model.dto;

public class GroupeDTO {
    private String nomGroupe;
    private int effectif;

    public String getNomGroupe() { return nomGroupe; }
    public void setNomGroupe(String nomGroupe) { this.nomGroupe = nomGroupe; }

    public int getEffectif() { return effectif; }
    public void setEffectif(int effectif) { this.effectif = effectif; }
}
